Diego García González
UO294255

Entrega mayo JDBC.

He implementado todos los casos de uso como bien indica en la entrega a realizar.
El resultado de dicha ejecución es de "Runs 187/187, Errors 0, Failures 0"

Además he modificado siguiendo los comentarios de la corrección todas las clases del proyecto que tenían errores.

Ambos proyectos, están en la version JavaSE-17, tal y como pedía con anterioridad de mantener la misma versión
que en los equipos de laboratorio.

Respecto a la checklist, la he revisado y con la herramienta search he buscado todos los errores que he podido 
para dejar el proyecto lo más perfecto posible.