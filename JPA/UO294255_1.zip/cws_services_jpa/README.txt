Diego García González
UO294255
Modelo de ejercicio 1:
* Listar pedidos y ver detalle de pedido
* Gestionar proveedores
* Gestionar repuestos suministrados por proveedor
* Recibir pedido